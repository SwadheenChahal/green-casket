<?php
$username="u496468587_android";
$password="@Android1234";
$hostname = "localhost";
$dbName="u496468587_green_casket";


$dbhandle = mysqli_connect($hostname, $username, $password,$dbName)
or die("Unable to connect to MySQL");
?>
