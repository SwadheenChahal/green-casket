<?php
ob_start();
session_start();

require_once __DIR__ . '../../greencasket/dbs/myphpcon.php';

//include "dbh.php";
?>
